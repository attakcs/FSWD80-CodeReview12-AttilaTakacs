    <?php get_header(); ?>
    <hr class="py-3">
    <main class="container">
   
        <div class="row">

        <?php 
        while(have_posts()) {
        the_post(); ?>
        
        
            <article class="col-md-6 col-lg-4 text-center mt-3">
                <a href="<?php the_permalink() ?>">
                    <?php the_post_thumbnail(); ?></a>
                <div class="title text-uppercase"><?php the_title(); ?></div>
                <div class="content"><?php the_content(); ?></div>
                <div class="date text-muted mb-3"><i><?php the_time('F j, Y'); ?></i></div>
            </article>

        <?php } ?>

        </div>
    </main>
    
<?php get_footer(); ?>