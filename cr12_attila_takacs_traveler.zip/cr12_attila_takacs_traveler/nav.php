<nav class="bg-light navbar-light">
        <div class="container d-flex justify-content-between">
            <div class="navbar navbar-expand-md">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <a class="navbar-brand" href="#"></a>
                <?php 
                wp_nav_menu( array(
                    'theme_location'  => 'primary',
                    'depth'           => 3, // 1 = no dropdowns, 2 = with dropdowns.
                    'container'       => 'div',
                    'container_class' => 'collapse navbar-collapse',
                    'container_id'    => 'navbarTogglerDemo03',
                    'menu_class'      => 'navbar-nav mr-auto mt-2 mt-lg-0 text-uppercase text-center',
                    'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                    'walker'          => new WP_Bootstrap_Navwalker(),
) );

                 ?>

            </div>

            <?php
            if(is_active_sidebar('socialheader')):
                dynamic_sidebar('socialheader');
            endif; ?>
        </div>
    </nav>